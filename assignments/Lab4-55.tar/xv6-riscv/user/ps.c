#include "kernel/types.h"
#include "user/user.h"

int main(void)
{
  showprocs();
  exit(0);
}

