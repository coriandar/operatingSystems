/**
 * Lab3: Assignment
 * Group55: Jamie Lee, Tony Yee
 **/

#ifndef LISTFUNCS_H
#define LISTFUNCS_H

// prototypes
int insert_after(List_item*, List_item*, int);
int remove_item(List_item*, int);
void print_linked_list(List_item*);

#endif