/**
 * Lab3: Assignment
 * Group55: Jamie Lee, Tony Yee
 **/

#ifndef PROG4_H
#define PROG4_H

// define null value in header.
#define null 0

// define struct in header.
typedef struct List_item
{
    int item_num;
    struct List_item* next;
} List_item;

#endif